package com.example.cyparking.chat;

public class ChatUser {
    String username;
    public ChatUser(String username) {
        this.username = username;
    }
    public String getUsername(){
        return username;
    }
}
