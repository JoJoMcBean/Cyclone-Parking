package com.example.cyparking.spin;

public enum  UserType {
    NORMAL_USER, PARKING_DIVISION, TOWING_CONPANY;
}
